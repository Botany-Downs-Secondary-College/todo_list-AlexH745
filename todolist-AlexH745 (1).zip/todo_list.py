#todo_list.py
def menu( ):
  mode=input("Choose a mode 1: add task 2: view list 3: Exit")
  return mode

def add_tasks():
  while True:
    new_task=input("entertask to add or type end to return menu").strip().lower()
    if new_task=="end":
      break
    else:
      todo_list.append(new_task)
def view_list():
  for task in todo_list:
    print("- {}".format(task))

todo_list = []
while True:
  chosen_option=menu()

  if chosen_option=="1":
      add_tasks()
  elif chosen_option=="2":
      print("here is your to do list")
      view_list()
  elif chosen_option=="3":
      break
  else:
      print("This is not an option try again")
print("bye.")

